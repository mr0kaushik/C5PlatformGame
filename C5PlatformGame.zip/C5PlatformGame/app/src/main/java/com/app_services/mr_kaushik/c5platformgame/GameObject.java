package com.app_services.mr_kaushik.c5platformgame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public abstract class GameObject {
    private Vector2Point5D worldLocation;
    private float width;
    private float height;

    private boolean active;
    private boolean visible;
    private int animFrameCount;
    private char type;

    private String bitmapName;
    public abstract void update(long fps, float gravity);

    public GameObject(){
        this.active = true;
        this.visible = true;
        this.animFrameCount = 1;
    }

    public String getBitmapName() {
        return bitmapName;
    }

    public Bitmap prepareBitmap(Context context, String bitmapName, int pixelsPerMetre){
        int resId = context.getResources().getIdentifier(bitmapName, "drawable", context.getPackageName());
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(),resId);
        bitmap = Bitmap.createScaledBitmap(bitmap, (int) (width*animFrameCount*pixelsPerMetre), (int)(height*pixelsPerMetre), false);
        return bitmap;
    }

    public Vector2Point5D getWorldLocation() {
        return worldLocation;
    }

    public void setWorldLocation(float x, float y, int z){
        this.worldLocation = new Vector2Point5D();
        this.worldLocation.x = x;
        this.worldLocation.y = y;
        this.worldLocation.z = z;
    }

    public void setBitmapName(String bitmapName){
        this.bitmapName = bitmapName;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public boolean isActive() {
        return active;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }
}
