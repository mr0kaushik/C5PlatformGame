package com.app_services.mr_kaushik.c5platformgame;

import android.graphics.Rect;

public class Viewport {

    private Vector2Point5D vector2Point5D;
    private Rect convertedRect;

    private int pixelsPerMetreX;
    private int pixelsPerMetreY;

    private int screenXResolution;
    private int screenYResolution;

    private int screenCentreX;
    private int screenCentreY;

    private int metresToShowX;
    private int metresToShowY;

    private int numClipped;

    public Viewport(int x, int y) {
        screenXResolution = x;
        screenYResolution = y;
        screenCentreX = screenXResolution/2;
        screenCentreY = screenYResolution/2;
        pixelsPerMetreX = screenXResolution/32;
        pixelsPerMetreY = screenYResolution/18;
        metresToShowX = 34;
        metresToShowY = 20;

        convertedRect = new Rect();
        vector2Point5D = new Vector2Point5D();
    }
    void setWorldCentre(float x, float y) {
        vector2Point5D.x = x;
        vector2Point5D.y = y;
    }


    public int getPixelsPerMetreX() {
        return pixelsPerMetreX;
    }

    public int getScreenXResolution() {
        return screenXResolution;
    }

    public int getScreenYResolution() {
        return screenYResolution;
    }

    public Rect worldToScreen(float objectX, float objectY, float objectWidth, float objectHeight){

        int left = (int) (screenCentreX - ((vector2Point5D.x - objectX) * pixelsPerMetreX));
        int top = (int) (screenCentreY -  ((vector2Point5D.y - objectY) * pixelsPerMetreY));
        int right = (int) (left + (objectWidth * pixelsPerMetreX));
        int bottom = (int) (top + (objectHeight * pixelsPerMetreY));
        convertedRect.set(left, top, right, bottom);
        return convertedRect;
    }

    public boolean clipObjects(float objectX, float objectY, float objectWidth, float objectHeight) {
        boolean clipped = true;
        if (objectX - objectWidth < vector2Point5D.x + (metresToShowX / 2)) {
            if (objectX + objectWidth > vector2Point5D.x - (metresToShowX / 2)) {
                if (objectY - objectHeight < vector2Point5D.y + (metresToShowY / 2)) {
                    if (objectY + objectHeight > vector2Point5D.y - (metresToShowY / 2)){
                        clipped = false;
                    }
                }
            }
        }

        if(clipped){
            numClipped++;
        }
        return clipped;
    }
}
