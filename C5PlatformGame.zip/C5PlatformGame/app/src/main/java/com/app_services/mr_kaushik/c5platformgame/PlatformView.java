package com.app_services.mr_kaushik.c5platformgame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class PlatformView extends SurfaceView implements Runnable {


    private boolean debugging = true;
    private volatile boolean running;
    private Thread gameThread = null;

    private Paint paint;

    private Canvas canvas;
    private Context context;
    private SurfaceHolder ourHolder;
    private int screenX, screenY;


    long startFrameTime;
    long timeThisFrame;
    long fps;

    private LevelManager levelManager;
    private Viewport viewport;
    InputController ic;

    PlatformView(Context context,  int x, int y){
        super(context);
        this.context = context;
        this.screenX = x;
        this.screenY = y;
    }

    public void resume(){
        running = true;
        gameThread = new Thread(this);
        gameThread.start();

    }
    public void pause(){
        running = false;
        try{
            gameThread.join();
        }catch (InterruptedException e){
            Log.e("error", "failed to pause thread");
        }

    }

    @Override
    public void run() {
        while(running){
            startFrameTime = System.currentTimeMillis();
            update();
            draw();
            timeThisFrame = System.currentTimeMillis() - startFrameTime;
            if(timeThisFrame >= 1)
            {
                fps = 1000 / timeThisFrame;
                Log.i("FPS : ", String.valueOf(fps));
            }
        }

    }

    private void update() {

    }


    private void draw(){

        if(ourHolder.getSurface().isValid()){
            canvas = ourHolder.lockCanvas();

            paint.setColor(Color.argb(255, 0, 0, 255 ));
            canvas.drawColor(Color.argb(255,0,0,255));



            ourHolder.unlockCanvasAndPost(canvas);
        }
    }
}
